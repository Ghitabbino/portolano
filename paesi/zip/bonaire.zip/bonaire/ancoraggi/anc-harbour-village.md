# Harbour Village Marina {#anc-harbour-village}

[← Tutti gli ancoraggi](../08-ancoraggi.md)
**12°09′44″ N 68°17′19″ W** ★★★★ — ingresso bacino (WGS84, Navily/Harbour Village)

| Campo | Dettaglio |
|---|---|
| **Profondità** | ~4,5 m all'ingresso; bacino interno protetto con fondale sabbia/corallo dragato |
| **Tenuta àncora** | — (marina resort, non ancoraggio: **àncora vietata** nel BNMP) |
| **Venti/riparo** | Ottimo riparo dagli alisei ENE (bacino a nord di Kralendijk); esposta a swell N/NO con fronti freddi — verificare bollettino prima dell'ingresso ★★ |
| **Pericoli** | Traffico resort/charter all'ingresso; fondale che degrada rapidamente fuori dal bacino; reef a sud dell'imboccatura |
| **Boe/divieti/normative** | **Gestore ufficiale delle boe overnight STINAPA** per visitatori: assegnazione first-come via VHF 17 (e 12), pagamento in loco US$ 35/notte, briefing uso boa (cima ≥6 m, max 18 m, una barca/boa) ★★★★★; Dogana/Immigrazione a 0,5 M a sud (Fort Oranje) — unico porto d'ingresso |
| **A terra** | Resort 5★ full-service: **60 posti** fino a 60 ft + mega-yacht dock fino a **240 ft (Ambar Point)**; acqua US$0,10/gal, elettricità US$0,75/kWh (127–130V 30A / 230–240V 50A), diesel/benzina + bunker >10.000 l via Curoil, pump-out WiFi docce lavanderia parcheggio sicurezza inclusi; prenotazione [Request Slip](https://www.harbourvillage.com/bonaire-marina) |
| **Contatti & orari** | Tel **+599 717 7419** · WhatsApp **+599 701 7500** · dockmaster@harbourvillage.com · VHF **17** (mooring) / **12** (disponibilità) / 16 ascolto · Lun–ven 8:30–12:00 & 13:30–17:00, sab 8:00–13:00 ★★★★ |
| **Affollamento** | Medio-alto in alta stagione (dic–apr): prenotare prima della traversata; check-out mezzogiorno, pagamento anticipato |

<div class="mapframe" data-slug="anc-harbour-village" data-minz="12" data-maxz="17" data-lat="12.1623" data-lon="-68.2887"></div>
*Cartina di dettaglio — zoom ± fino alla baia · mappa offline · coordinate WGS84 indicative, verificare sempre con plotter. **Marker in mezzo al mare**, davanti all'imboccatura.*

Fonti: [Harbour Village Marina — Rates & Services](https://www.harbourvillage.com/bonaire-marina) ★★★★ · [STINAPA — Mooring](https://stinapabonaire.org/rules-and-regulations/mooring/) ★★★★★ · [Navily — Harbour Village Marina 12°09.83' N 68°17.08' W](https://www.navily.com/port/harbour-village-marina/8105) ★★★ · [InfoBonaire — Yachting & Cruising](https://infobonaire.com/getting-to-bonaire/yachting-cruising/) ★★★

Ultimo aggiornamento: 28/08/2026
