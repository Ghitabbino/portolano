venezuela — SailTropics Portolano
WGS84 — ZIP offline paese
Apri i .md con qualsiasi editor o importa il .gpx in OpenCPN/Navionics
