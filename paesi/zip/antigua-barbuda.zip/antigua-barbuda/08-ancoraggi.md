# 08 — Ancoraggi

## Ancoraggi in dettaglio

| # | Ancoraggio | Riparo | Fondo | Prof. | Boe |
|---|---|---|---|---|---|
| 1 | [English Harbour (Freeman)](ancoraggi/anc-english-harbour.md) | ★★★★★ | Sabbia | 4–10 m | No (parco ~US$15/notte ⚠️) |
| 2 | [Falmouth Harbour](ancoraggi/anc-falmouth.md) | ★★★★ | Sabbia e fango | 5–12 m | Boe AYC Marina ⚠️ |
| 3 | [Jolly Harbour](ancoraggi/anc-jolly.md) | ★★★ | Sabbia | 4–6 m | Marina US$1,80–2,50/piede/notte; boe esterne no |

<div class="mapframe" data-lat="17.03" data-lon="-61.80" data-markers='[[17.00425,-61.76365,"English Harbour (Freeman)","anc-english-harbour"],[17.01474,-61.77464,"Falmouth Harbour","anc-falmouth"],[17.053,-61.868,"Jolly Harbour","anc-jolly"]]' data-zoom="11"></div>
*Cartina generale — clicca l'àncora gialla per aprire la scheda di dettaglio · zoom fino alla baia — pin verificati in mezzo al mare (WGS84)*

**Ultimo aggiornamento: 23/08/2026**


| Ancoraggio | Protezione | Fondo / profondità | Note |
|---|---|---|---|
| **English Harbour** | Ottima ogni vento | Sabbia, 3–8 m | Nelson's Dockyard; niente ancoraggio nei canali segnalati; tasse all'Harbour Master ★★★★ |
| **Falmouth Harbour** | Ottima | Sabbia/posidonia, 4–10 m | Ampa a ferro di cavallo; boe disponibili; 3 marine — [Navily](https://www.navily.com/mouillage/falmouth-harbour/13119) ★★★★ |
| **Jolly Harbour** | Ottima | — | **Vietato ancorare**: solo boe limitate; canale dragato 15 ft ★★★★ |
| Five Islands / Deep Bay | Buona con NE | Sabbia | Tranquilla, rovine Fort Barrington ★★ |
| **Barbuda — Codrington Lagoon** | Esposta all'ingresso | Sabbia bassa | Frigatibirds; guida locale consigliata; scogli costa ovest ⚠️ ★★ |

⚠️ Scogli lungo la costa NE e attorno Barbuda; navigazione notturna sconsigliata (regole charter) ★★★

Fonte: [safetyanchoralarm](https://safetyanchoralarm.com/anchorages/antigua-barbuda) · [ABYMA](https://abyma.ag/yachting/anchorages/)

Distanze: Antigua–Barbuda ~45 km N · Antigua–Guadeloupe ~65 km S · Antigua–St-Barth ~90 km NW

Ultimo aggiornamento: 23/08/2026