# 03 — Porti e marine

**Ultima verifica: 27/08/2026** · Coordinate in gradi decimali o N/W come da fonte — **DATO MANCANTE** dove non verificato

## Costa mediterranea — inquadramento

La costa mediterranea egiziana va da Sallum/Alessandria a Port Said; quella sul Mar Rosso da Suez a Hurghada/Marsa Alam. Questo portolano copre la sola sezione mediterranea. **DATO MANCANTE** su distinzione Mediterraneo/Mar Rosso per procedure — da verificare su Egyptian Maritime Authority.

### DATO MANCANTE — area principale / porto di ingresso

- **DATO MANCANTE** — porti, coordinate, VHF, servizi. Verificare su elenco ufficiale Port Authority Egitto.

### DATO MANCANTE — seconda area / costa

- **DATO MANCANTE**

### DATO MANCANTE — isole / arcipelago (se presente)

- **DATO MANCANTE**

## Tariffe ormeggi e marine

> Stesse voci per tutti i paesi; **DATO MANCANTE** = da ricercare al controllo mensile.

### DATO MANCANTE — marina di riferimento (da definire)

| Voce | Costo | Note |
|---|---|---|
| Posto pontile — notte (~12 m) | **DATO MANCANTE** | **DATO MANCANTE** |
| Posto pontile — notte (multiscafo ~12 m) | **DATO MANCANTE** | **DATO MANCANTE** |
| Boa / mouillage — notte (~12 m) | **DATO MANCANTE** | **DATO MANCANTE** |
| Mese pontile (~12 m) | **DATO MANCANTE** | **DATO MANCANTE** |
| Elettricità | **DATO MANCANTE** | **DATO MANCANTE** |
| Acqua | **DATO MANCANTE** | **DATO MANCANTE** |
| Ancoraggio | **DATO MANCANTE** | **DATO MANCANTE** |

### Altre strutture

| Struttura | Costo/note | Fonte |
|---|---|---|
| **DATO MANCANTE** | **DATO MANCANTE** | **DATO MANCANTE** |

⚠️ **Da verificare prima della crociera**: listini marine, prenotazioni alta stagione, regolamenti ancoraggio.

## Distanze utili

| Tratta | Distanza |
|---|---|
| **DATO MANCANTE** | **DATO MANCANTE** |

Ultimo aggiornamento: 27/08/2026
