# 00 — Ingresso, documenti e visti

**Ultima verifica: 28/08/2026**

## Status

Barbados è una **repubblica parlamentare indipendente** dal 30 novembre 2021 (ex-reame del Commonwealth), membro del Commonwealth, **fuori dall'UE e fuori dall'area Schengen**: dogana e immigrazione proprie, non OECS. Le regole UE/Schengen non si applicano. [immigration.gov.bb](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ · [gov.bb — Immigration Department](https://www.gov.bb/Departments/immigration) ★★★★★

## Cittadini UE — nessun visto per soggiorni brevi

| Voce | Regola | Fonte |
|---|---|---|
| Visto | **Non richiesto** per cittadini italiani/UE e numerose altre nazionalità per turismo/visita; la lista visti richiesti include solo alcuni paesi (es. Dominican Rep., Haiti, Cuba, Cina ecc. — non UE) | [barbados.org — Documents Required](https://barbados.org/docs_requirements.htm) ★★★ · [immigration.gov.bb — Requirements](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ |
| Documenti obbligatori | **Passaporto valido per tutta la durata del soggiorno** (alla partenza deve essere ancora valido); **biglietto di ritorno o proseguimento**; **indirizzo di alloggio** (hotel/appartamento o barca con ancoraggio/marina); **prova di mezzi sufficienti**; **Immigration & Customs Form online** compilato e ricevute salvate/stampate | [immigration.gov.bb — Visitor Information](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ · [travelform.gov.bb](https://travelform.gov.bb) ★★★★★ |
| Modulo online obbligatorio | **Immigration and Customs Form** su [travelform.gov.bb](https://travelform.gov.bb) **disponibile entro 72 h prima dell'arrivo**; va compilato online (anche pre-registrazione imbarcazioni) e le **ricevute Immigration + Customs vanno salvate su telefono o stampate** per il controllo all'arrivo | [immigration.gov.bb](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ · [travelform.gov.bb](https://travelform.gov.bb) ★★★★★ · [barbados.org](https://barbados.org/docs_requirements.htm) ★★★ |
| Soggiorno turistico | **Tipicamente fino a 3 mesi** all'ingresso per cittadini UE/esenti, a discrezione dell'ufficiale di frontiera; timbro sul passaporto fa fede | Fonti diportiste aggregate ★★★(agg. 05/12/2025) ★★★ · [barbados.org — Duration](https://barbados.org/docs_duration.htm) ★★★ |
| Minori <18 anni | Se non accompagnati da genitore/tutore legale: **lettera di consenso notarile** con durata, adulto autorizzato a ricevere il minore e recapiti; originale + copia. Se con adulto diverso dal genitore/tutore: stessa lettera notarile con identificazione dell'accompagnatore | [immigration.gov.bb](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ |

⚠️ **Attenzione**: l'ammissione finale spetta sempre all'ufficiale di frontiera al porto d'ingresso; anche senza visto l'ingresso può essere rifiutato o limitato se i requisiti non sono soddisfatti.

## Nota importante per chi arriva via mare

- I controlli **persone** (Immigrazione) e **barca** (Dogana + Port Health + Port Authority) sono **separati ma collegati**: la barca va presentata al **Port of Entry ufficiale** e l'equipaggio deve aver completato la **Immigration & Customs Form** online. La clearance barca è obbligatoria all'entrata e all'uscita → vedi [01 — Clearance](01-clearance.md).
- **Porti d'ingresso (POE) per yacht: Bridgetown** (Shallow Draught dedicato agli yacht + Deep Water Harbour su istruzione) **e Port St. Charles Marina** (NW, clearance direttamente in marina fronte frangiflutti). **NON presentarsi alla banchina crociere/porto commerciale** con unità <20 m: pericoloso, senza pontile — meglio arrivare fuori e procedere col dinghy al Passenger Terminal su istruzione Signal Station. [Barbados Port Inc. — Vessel Documentation](https://barbadosport.com/vessel-documentation) ★★★★★ · Fonti diportiste aggregate ★★★ · Fonti diportiste aggregate ★★★
- **Avvicinamento Bridgetown**: chiamare **Signal Station di Bridgetown su VHF 12 (nominativo "8P")** prima di entrare; verrà assegnato il berth; issare **bandiera Q gialla** ben visibile entrando. Ancoraggio usuale post-clearance a **Carlisle Bay (5–10 m su sabbia)**, poi dinghy/taxi verso gli uffici. La nave viene solitamente **boardata a bordo** da Port Health + Dogana + Immigrazione (~10 min per la Free Pratique); sono accettati i moduli propri della nave. Servono: ship's particulars, **lista degli ultimi 10 porti toccati**, crew e passenger lists, zarpe del porto precedente.
- **Avvicinamento Port St. Charles**: ancoraggio esterno su sabbia davanti alla marina, poi dinghy al pontile interno; ufficiali **nello stesso stabile in fondo al frangiflutti** (dogana/immigrazione/coast guard/polizia) — procedura descritta come rapida e cordiale (report Fonti diportiste aggregate 30/11/2025). Fonti diportiste aggregate ★★★
- **Pre-arrivo digitale**: **SailClear** ([sailclear.com](https://www.sailclear.com)) consigliato come pre-avviso doganale (Barbados è tra i paesi SailClear CCLEC dal 2013); non sostituisce la presenza in banchina ma accelera la pratica; SailClear dal 01/05/2024 ha fee annuale US$25. [SailClear](https://www.sailclear.com) ★★★ · [CCLEC — SailClear](https://www.cclec.org/about-us/sailclear/) ★★★

## E dopo i 3 mesi? (cittadini italiani/UE)

| Situazione | Regola | Fonte |
|---|---|---|
| Proroga soggiorno turistico | Richiesta presso **Immigration Department** (BTI Corporate Centre, Princess Alice Highway, Bridgetown BB11093 — tel +1 246 535-4100 · imm-dept@caribsurf.com / immigration@barbados.gov.bb) o agli uffici aeroporto/porto (Grantley Adams +1 246 418-4180 · Passenger Terminal +1 246 535-4172 · Port St. Charles +1 246 535-4178) | [gov.bb — Immigration Contacts](https://www.gov.bb/Departments/immigration) ★★★★★ · [immigration.gov.bb](https://immigration.gov.bb) ★★★★★ |
| Durata estensione | **DATO MANCANTE** — nessuna fonte governativa pubblicata trovata con durata massima, fee e moduli proroga turistica al 28/08/2026; verificare con Immigration prima della crociera | — |
| Sforamento (overstay) | Può comportare rifiuto di future ammissioni / annotazione; l'ingresso può già essere stato abbreviato in frontiera per mezzi insufficienti | [immigration.gov.bb](https://immigration.gov.bb/pages/visitor.aspx) ★★★★★ |

In pratica: con passaporto italiano si entra senza visto fino a ~90 giorni, con travelform 72h; per restare oltre serve pratica in loco presso Immigration — tempi/costi da verificare.

## La barca: ammissione temporanea e tasse

| Voce | Regola | Fonte |
|---|---|---|
| **Ammissione temporanea yacht straniero** | Uso privato consentito in importazione temporanea; la barca deve lasciare le acque al termine del periodo concesso; vietati noleggio/vendita e uso commerciale senza sdoganamento. Durata prassi **DATO MANCANTE** per Barbados specifico (per analogia OECS/ABC 6 mesi prassi — da confermare) | **DATO MANCANTE** per testo doganale Barbados specifico ★★ |
| **Cruising permit / anchor fees** | **DATO MANCANTE** — nessuna tariffa pubblicata su barbadosport.com/bpi al 28/08/2026 trovata come tariffario ancoraggio | — |
| **Clearance in/out fee** | **BBD 100 (circa US$ 50)** pagati **all'uscita** secondo Fonti diportiste aggregate 2025; da confermare in Dogana | Fonti diportiste aggregate ★★★(05/12/2025) ★★★ |
| **Tassa ambientale barca** | **DATO MANCANTE** — nessuna fonte governativa su tassa ambientale specifica per yacht trovata | — |
| **Dogana/Immigrazione barca** | Formalità gratuite in orario salvo fee uscita sopra | Fonti diportiste aggregate ★★★ |

## Vaccini

| Voce | Dettaglio | Fonte |
|---|---|---|
| Obbligo febbre gialla | **Non richiesta** per arrivi diretti da UE/Italia/USA. **Richiesta solo se si proviene o si è transitati >12 h in Paese a rischio trasmissione** (area amazzonica, Africa sub-sahariana — lista OMS). Esenzione per Guyana e Trinidad salvo focolai urbani secondo fonte secondaria (rilevante per rotte dal Sud America) | [CDC — Barbados Traveler View](https://wwwnc.cdc.gov/travel/destinations/traveler/none/barbados) ★★★★★ · [NaTHNaC — Barbados](https://travelhealthpro.org.uk/country/9/barbados) ★★★★★ · [IAMAT / traveldoctor.network](https://www.traveldoctor.network/country/barbados/risk/yellow-fever) ★★★ |
| Validità certificato YF | **A vita dal 11/07/2016** (OMS): non può essere rifiutato per anzianità >10 anni | NaTHNaC / OMS ★★★★★ |
| Età | Richiesta **dai 12 mesi in su** dove applicabile | [traveldoctor.network](https://www.traveldoctor.network) ★★★ |
| Altri vaccini | **Nessun altro obbligatorio** per arrivi da UE; raccomandata protezione anti-zanzare (dengue presente) | [CDC](https://wwwnc.cdc.gov/travel/destinations/traveler/none/barbados) ★★★★★ |

Ultimo aggiornamento: 28/08/2026
