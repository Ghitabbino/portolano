# Costo della vita

**Ultimo aggiornamento: 23/08/2026**

> ⚠️ Pagina in preparazione: dati in raccolta.

Ultimo aggiornamento: 23/08/2026
