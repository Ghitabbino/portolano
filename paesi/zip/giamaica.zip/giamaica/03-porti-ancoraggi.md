# 03 — Porti e marine

**Ultima verifica: 24/08/2026** · Coordinate WGS84 · VHF 16 su tutte le marine

## Nord-est — Port Antonio

### Errol Flynn Marina & Boatyard ⚓ porto d'ingresso
- **18°10.83'N 076°27.22'W** (18°10'08"N 76°27'02"W) · **VHF 16/68** · **tel +1 (876)715-6044 / 715-6046** · mail via errolflynnmarina.com · errolflynnmarina.com ★★★★
- 32 slips fino a **350 ft LOA**, pescaggio max **17 ft (5,2 m)**, canale dragato protetto (troppo basso per cruise ship). Energia **single/three-phase** metered, acqua banchina, **pumpout**, TV via cavo, **carburante diesel ULSD + benzina 90 ottani** (disponibilità variabile — chiamare), WiFi, docce, lavanderia, ghiaccio, **24h security + video**, **Travelift 100 t** (unico nel nord Caraibi, fino a 106 m / 9,10 m draft), pool, bar, ristorante **Norma's**, helipad 4 elicotteri. Dogana **24h in loco**, più raccomandato per clearance. ★★★★
- Tariffe ufficiali: **standard US$0,95/ft/giorno** dock · ancoraggio **US$25/giorno** (2023); **OceanPosse: ≤50 ft US$0,70 · 50–99 ft US$1,15 · >100 ft US$2,00 /ft/giorno** — menzionare sconto all'arrivo, non retroattivo, utilities a consumo escluse ★★★. Overtime Customs weekend **US$150/imbarcazione** ★★★.

**Esempio 1–30 gg (standard, + GCT se applicata):**
| LOA | 10 m (32,8 ft) | 12 m (39,4 ft) | 15 m (49,2 ft) |
|---|---|---|---|
| EFM dock US$0,95/ft | **US$31/giorno** | **US$37** | **US$47** |
| EFM OceanPosse ≤50ft US$0,70 | US$23 | US$28 | US$34 |
| Ancora | US$25 flat | US$25 | US$25 |

Elettricità: **DATO MANCANTE** costo/kWh (metered, chiedere in office). Acqua: a banchina metered. ★★

## Nord-ovest — Montego Bay

### Montego Bay Yacht Club (MBYC) ⚓ porto d'ingresso
- **18°28'N 077°55'W** (Freeport Peninsula, 18°27'44.8"N 77°56'35.8"W) · **VHF 16** · **tel +1 (876)979-8038 / 979-8002** · mail via mobayyachtclub.com · Sangster Airport weather **952-0181** ★★★★
- Finger pier con **T-head**, profondità **6–20 ft**, ormeggio **stern-to con propria ancora** su entrambi i lati. Acqua potabile sicura su molo, **diesel + benzina su molo** (preordine obbligatorio **>2.000 gal**), ristorante **10–22 7/7**, bar con pool table, lavanderia, **meteo Sangster Airport**, **security Freeport Police <1 miglio**, CCTV. ★★★★
- Tariffe ufficiali 2026 (mobayyachtclub.com ★★★★): **1–30 gg US$1,25/ft mono · US$2,50 cat** ; **>30 gg US$0,90 mono · US$1,80 cat** ; **barca alla fonda US$10/persona/giorno** + **GCT 15–16,5%**. Clearance **gratuita 09–16 feriale**, **US$80 dopo 16:00** feriale, **US$150 weekend/festivi** (Customs overtime) ★★★★.

**Esempio 1–30 gg mono (prima di GCT):**
| LOA | 10 m (32,8 ft) | 12 m (39,4 ft) | 15 m (49,2 ft) |
|---|---|---|---|
| MBYC 1–30 gg | **US$41/giorno** | **US$49** | **US$62** |
| MBYC >30 gg | US$30 | US$35 | US$44 |
| Cat 1–30 gg (×2) | US$82 | US$99 | US$123 |
| Ancora facilities | US$10/pax/giorno | — | — |

Elettricità: **110V 50Hz shore power**, metered — **DATO MANCANTE** prezzo/kWh (chiedere ufficio). Acqua: potabile inclusa su molo. ★★

## Sud — Kingston

### Royal Jamaica Yacht Club (RJYC) ⚓ porto d'ingresso
- **17°56.72'N 076°46.37'W** (17°58'N 76°47'W, Palisadoes Park, accanto Norman Manley Airport & Caribbean Maritime University) · **VHF 16** · **tel (876)924-8685 / 924-8686** · mail **manager@rjyc.org.jm / rjycmanager@flowja.com / accounts@rjyc.org.jm (Maxine Chin)** · **rjyc.org.jm** ★★★★
- **7th largest natural harbour** (Kingston Harbour). **120 posti barca** + visitor dock fino a **50 ft** dichiarato (misure maggiori fino a **150 ft** su richiesta su visitor dock), pescaggio max **9 ft MLW** su visitor dock, profondità banchine **6–12 ft**. Shore power **110/220V 50Hz metered a consumo**, acqua potabile metered, **fuel dock diesel/benzina**, **24h security/CCTV**, clubhouse & dining, bar, pool, docce, lavanderia, **WiFi**, assistenza customs. Fondato **1889 Royal Charter Queen Victoria**. Regate: Spring Regatta feb, RJYC Globe Fishing mar, Independence Regatta lug/ago. ★★★★
- Tariffe: **US$1,73/ft/giorno listino –15% OceanPosse = US$1,47/ft/giorno** (panamaposse/oceanposse ★★★). Moon Jamaica riporta **US$1,50/ft primi 6 gg poi US$1,00/ft** ★★. Nightly/weekly/monthly su richiesta via **Transient Berth Request**; facilities per ancoraggio esterno a consumo. **DATO MANCANTE** tariffa ufficiale 2026 pubblicata su rjyc.org.jm (pagina Facilities/Rates non dettaglia). Chiedere mail prima dell'arrivo. ★★

**Esempio (US$1,47 OceanPosse):**
| LOA | 10 m (32,8 ft) | 12 m (39,4 ft) | 15 m (49,2 ft) |
|---|---|---|---|
| RJYC visitor | **US$48/giorno** | **US$58** | **US$72** |
| Listino pieno US$1,73 | US$57 | US$68 | US$85 |

Elettricità: **110/220V 50Hz metered** — **DATO MANCANTE** J$/kWh; acqua metered. ★★

## Altri porti d'ingresso secondari

### Ocho Rios
- **18°24.6'N 77°06.5'W**; cruise port, ancoraggio davanti a grocery/dinghy dock (Ocean Plaza) ma **rumoroso water sports**, evitare weekend con cruise ship. Fondale sabbia, tenuta ★★★. Dogana operativa ma personale limitato — preferire MBYC/EFM/RJYC per prima clearance. ★★

### Oracabessa (St Mary)
- **18°24.5'N 076°57'W**; baia riparata a ovest, ancoraggio sabbia **★4,9 NoForeignLand**, dogana efficiente **★5,0** (Marine Police). Fondo sabbia, tenuta ★★★★. Servizi a terra limitati (covered market + minimarket Main Street). ★★

### Bowden Harbour / Port Morant (St Thomas)
- **17°53'N 076°18'W**; **sconsigliato** ★2,0 (lento, possibile rinvio ad altro porto). Fondale fango 5,5 m, dinghy difficile. Dogana non 24h. ★★

## Tariffe ormeggi e marine — riepilogo comparato

> Stesse voci per tutti i paesi; **DATO MANCANTE** = da ricercare al controllo mensile.

| Voce | Costo | Note |
|---|---|---|
| Errol Flynn dock standard | **US$0,95/ft/giorno** | ★★★ · 10m US$31 · 12m US$37 · 15m US$47 |
| Errol Flynn OceanPosse | **≤50ft US$0,70 · 50–99ft US$1,15 · >100ft US$2,00** | ★★★ |
| Errol Flynn ancora | **US$25/giorno flat** | ★★★ |
| MBYC 1–30 gg mono | **US$1,25/ft/giorno** | ★★★★ · 10m US$41 · 12m US$49 · 15m US$62 |
| MBYC 1–30 gg cat | **US$2,50/ft/giorno** | ★★★★ · 12m cat US$99 |
| MBYC >30 gg mono | **US$0,90/ft/giorno** | ★★★★ · 10m US$30 · 12m US$35 |
| MBYC >30 gg cat | **US$1,80/ft/giorno** | ★★★★ |
| MBYC ancora facilities | **US$10/persona/giorno + GCT** | ★★★★ |
| RJYC visitor OceanPosse | **US$1,47/ft/giorno** (US$1,73 –15%) | ★★★ · 10m US$48 · 12m US$58 · 15m US$72 |
| Elettricità RJYC | **110/220V 50Hz metered** | **DATO MANCANTE** prezzo/kWh ★★ |
| Elettricità MBYC/EFM | **110V 50Hz shore power** | **DATO MANCANTE** prezzo/kWh ★★ |
| Acqua banchina | Metered RJYC · potabile MBYC | Inclusa vs consumo ★★ |
| GCT su dockage | **15–16,5%** aggiunta | MBYC ★★★★ |
| Multiscafo supplemento MBYC | **×2** (altrove **DATO MANCANTE** se diverso da ×2) | ★★★★ |

⚠️ **Da verificare prima della crociera**: profondità post-**Hurricane Melissa 10/2025** (porti riaperti ma non tutti i servizi — verificare visitjamaica.com/travel-alerts ★★★★★), disponibilità diesel Errol Flynn (variabile, chiamare VHF 16), tariffe RJYC aggiornate via mail.

## Distanze utili

| Tratta | Distanza | Note |
|---|---|---|
| Port Antonio – Kingston (via costa est) | **~50 M** | Costeggiare a 1 miglio per fish traps |
| Montego Bay – Port Antonio | **~120 M** | Via nord coast |
| Giamaica – Cuba (Santiago de Cuba) | **~90 M** | Rotta NW |
| Kingston – Ocho Rios (via mare) | ~55 M | — |
| Ocho Rios – Oracabessa | ~9 M | — |

## Contatti rapidi marine

| Marina | VHF | Telefono | Mail / Web |
|---|---|---|---|
| Errol Flynn | 16 | +1 876-715-6044/46 | errolflynnmarina.com |
| MBYC | 16 | +1 876-979-8038 | mobayyachtclub.com |
| RJYC | 16 | +1 876-924-8685/86 | manager@rjyc.org.jm · rjyc.org.jm |

Ultimo aggiornamento: 24/08/2026
